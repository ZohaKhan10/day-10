const express = require('express');
const { 
    getSignupForm,
    postSignupForm,
    getSigninForm,
    postSigninForm,
    postLogout
} = require('../controllers/accounts-controller');

const router = express.Router();

router.get('/signup', getSignupForm);
router.post('/signup', postSignupForm)

router.get('/signin', getSigninForm);
router.post('/signin', postSigninForm);


router.post('/logout', postLogout);


module.exports = router;